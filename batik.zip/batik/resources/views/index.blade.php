@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h4><i class="fa fa-user"></i> My Profile</h4>
                
        
            
</div>
      
    </div>
</div>
@endsection
